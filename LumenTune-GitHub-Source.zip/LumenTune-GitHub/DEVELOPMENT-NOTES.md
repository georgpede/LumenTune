# Lumen Tune — 0.3 experimental source release

An original, monophonic pitch-correction VST3/AU project intended for FL Studio on Windows and macOS. **This archive contains source code, not an installable VST3 binary.** The dependency-free DSP tests have run, and the plugin source passes a syntax-only compile against JUCE 8.0.6; a separate experimental Windows x64 VST3 binary and installer have now been cross-compiled and inspected. Windows execution, GUI rendering, host validation and listening tests have not been performed. Mac builds remain pending. It is not an Antares product, clone, or equivalent-quality replacement.

## Included

- Automatic nearest-note correction with key, chromatic / major / natural minor / major pentatonic scales.
- Tuning speed, correction amount, cents deadband and Relax (reduces correction depth).
- ±12 semitone transpose, sine vibrato depth/rate, saturation Character, wet mix and output gain.
- Mono, stereo and mono-to-stereo effect layouts, linked stereo pitch shift, automatable parameters and session state serialization.
- Latency-aware host bypass and deterministic DSP across varying buffer lengths.
- Windows x64 VST3/standalone targets; universal Intel/Apple Silicon macOS VST3/AU/standalone targets.
- Original charcoal/green interface, input/target note display and five original starting presets.
- CMake project using JUCE 8.0.6, Windows/macOS build scripts, manual GitHub build workflow and standalone C++ DSP tests.

A separate Windows release contains the compiled VST3 bundle and installer. This source tree also includes installer sources and a macOS packaging script. See COMPATIBILITY.md for format coverage, exclusions and validation status. FL Studio 26 on Windows is the primary requested host, but has not been tested.

## Explicit limitations

This is an early prototype, not a finished commercial tuner. The dual-window granular shifter can produce modulation, graininess, transient smear and phase coloration. Timbre and formants move with pitch. No formant preservation/designer, natural vibrato extraction, DVA, MIDI targeting, custom note masks, AI key/input detection, artist preset library, A/B management, undo, selectable latency modes or manual pitch editor is implemented. Generated sine vibrato is not natural vibrato preservation. Relax is a static reduction in correction strength, not sustained-note analysis.

Use dry, isolated, single-voice material. Chords, doubled vocals, noisy takes, breathy sounds and stereo phase cancellation can confuse detection. The detector's intended range is 60–1000 Hz; it uses a decimated YIN-style difference estimate with a simple input low-pass. The detector needs roughly 43 ms of history and updates about every 11 ms; short events may be missed. Nominal audio delay is approximately 20.7 ms at 48 kHz; wet granular timing varies around that center. Host compensation reports the center delay, not pitch-estimation response time. This is not a low-latency live monitoring product. At partial wet mix, phase coloration is possible. No limiter is included; monitor levels with positive gain or saturation.

## Build on Windows (64-bit)

Install Visual Studio 2022 with Desktop development with C++, CMake 3.22+, and Git. Internet access is needed for JUCE on first configuration. From a Developer PowerShell in this folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build-windows.ps1
```

The execution-policy option applies only to that process; alternatively run the three CMake commands in the script directly. Build output: `build/LumenTune_artefacts/Release/VST3/Lumen Tune.vst3`. Copy the **whole bundle** into `C:\Program Files\Common Files\VST3` (the OS may request administrator permission).

## Build on macOS

Install Xcode command-line tools, CMake 3.22+, and Git. Run:

```bash
bash scripts/build-macos.sh
```

This requests a universal Intel/Apple Silicon build. Copy the resulting whole `.vst3` bundle to `~/Library/Audio/Plug-Ins/VST3`. For AU hosts, copy `build/LumenTune_artefacts/Release/AU/Lumen Tune.component` to `~/Library/Audio/Plug-Ins/Components`. Standalone apps are also built. External distribution needs platform signing/notarization work; this project supplies no installer or distribution signing identity.

## FL Studio setup after a successful native build

Open Options > File settings > Manage plugins, enable Verify plugins, and run Find installed plugins. Load Lumen Tune on the vocal mixer insert. Choose the song key and scale; the preset buttons deliberately retain those settings. Start with Clean Start or Soft Landing. Neon Lock uses the fastest correction; Silver Motion adds generated vibrato; Low Orbit transposes down an octave.

See Image-Line's installation guide: https://www.image-line.com/fl-studio-learning/fl-studio-online-manual/html/basics_externalplugins.htm

## DSP tests without JUCE

```bash
g++ -std=c++17 -O2 Tests/DspTests.cpp -o dsp-tests
./dsp-tests
```

Or use `cmake -S . -B test-build -DLUMEN_DSP_ONLY=ON`, build it, and run `ctest --test-dir test-build --output-on-failure`.

`Tests/results.txt` records the checks actually run in the development environment. Tests verify a 452 Hz sine resolves toward A4, detector accuracy, scale mapping, silence, mono/stereo paths, reset, dry delay, host bypass, varying block sizes, sample-rate reset and finite output at extreme settings. They do not establish vocal transparency, full-range detector reliability, CPU suitability or FL Studio compatibility.

## Next release gates

1. Compile on the target OS and run a VST3 validator / pluginval.
2. Verify FL Studio scan, project reload, automation, transport reset, offline render, buffer-size changes and sample-rate changes.
3. Listen to exposed vocals across registers and transitions; measure octave errors, CPU spikes and grain artifacts.
4. Replace/improve the shifter and implement formant preservation before treating this as a transparent professional tuner.
5. Add the advanced controls only after audio and host stability are established.

## Dependencies and license

Original project source is provided under the MIT license in LICENSE. JUCE is downloaded separately and is not relicensed by this project. Its applicable AGPL/commercial terms must be reviewed for your distribution: https://juce.com/legal/juce-8-licence/ . VST3 dependency notices also retain their own terms. No Antares source, graphics or presets are included.

Reference product documentation: https://www.antarestech.com/documentation/autotune-advanced . This describes the reference product, not capabilities of Lumen Tune.
