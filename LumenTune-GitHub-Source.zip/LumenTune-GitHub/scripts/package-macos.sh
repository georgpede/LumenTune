#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
artifacts='build/LumenTune_artefacts/Release'
test -d "$artifacts/VST3/Lumen Tune.vst3"
test -d "$artifacts/AU/Lumen Tune.component"
staging="$(mktemp -d "${TMPDIR:-/tmp}/LumenTune-package.XXXXXX")"
trap 'rm -rf "$staging"' EXIT
mkdir -p "$staging/VST3" "$staging/Components" dist
ditto "$artifacts/VST3/Lumen Tune.vst3" "$staging/VST3/Lumen Tune.vst3"
ditto "$artifacts/AU/Lumen Tune.component" "$staging/Components/Lumen Tune.component"
pkgbuild --root "$staging" --install-location /Library/Audio/Plug-Ins --identifier audio.lumen.lumentune --version 0.3.0 dist/LumenTune-0.3-macOS-unsigned.pkg
printf '%s\n' 'Created unsigned macOS installer. Sign/notarize and validate before public distribution.'
