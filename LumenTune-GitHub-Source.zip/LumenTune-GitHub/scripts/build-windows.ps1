$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
cmake -S . -B build -G 'Visual Studio 17 2022' -A x64
if ($LASTEXITCODE -ne 0) { throw 'CMake configure failed' }
cmake --build build --config Release --parallel
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
ctest --test-dir build -C Release --output-on-failure
if ($LASTEXITCODE -ne 0) { throw 'DSP tests failed' }
Write-Host 'Built: build/LumenTune_artefacts/Release/VST3/Lumen Tune.vst3'
Write-Host 'Copy the entire .vst3 bundle into C:\Program Files\Common Files\VST3 and rescan FL Studio.'
Write-Host 'Standalone: build/LumenTune_artefacts/Release/Standalone/Lumen Tune.exe'
