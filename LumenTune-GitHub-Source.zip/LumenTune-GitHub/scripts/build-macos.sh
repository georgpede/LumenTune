#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release '-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64' -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
printf '%s\n' 'Built: build/LumenTune_artefacts/Release/VST3/Lumen Tune.vst3' 'Copy the bundle to ~/Library/Audio/Plug-Ins/VST3 and rescan FL Studio.'
printf '%s\n' 'AU: build/LumenTune_artefacts/Release/AU/Lumen Tune.component' 'Copy the AU bundle to ~/Library/Audio/Plug-Ins/Components for AU hosts.' 'Standalone: build/LumenTune_artefacts/Release/Standalone/Lumen Tune.app'
