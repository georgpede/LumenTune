#include "../Source/TuningEngine.h"
#include <iostream>
#include <vector>
#include <stdexcept>
#include <random>
void check(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
double spectralPeak(const std::vector<float>& x,double sr,double lo,double hi){
    double best=0,frequency=0;
    int count=std::min(static_cast<int>(x.size()),static_cast<int>(sr));int start=static_cast<int>(x.size())-count;
    for(double hz=lo;hz<=hi;hz+=0.25){
        double re=0,im=0;
        for(int i=0;i<count;++i){double w=0.5-0.5*std::cos(2*lumen::pi*i/(count-1));double angle=2*lumen::pi*hz*i/sr;re+=x[start+i]*w*std::cos(angle);im+=x[start+i]*w*std::sin(angle);}
        double power=re*re+im*im;if(power>best){best=power;frequency=hz;}
    }return frequency;
}
int main(){try{
    check(lumen::allowed(60,0,1)&&!lumen::allowed(61,0,1),"Major scale mapping");
    check(lumen::allowed(63,0,2)&&!lumen::allowed(64,0,2),"Minor scale mapping");
    check(std::abs(lumen::targetNote(69.3f,0,0)-69)<0.01f,"Nearest note");
    for(double sr:{44100.,48000.,96000.}){
        lumen::Engine e;e.prepare(sr);lumen::Settings s;s.drift=0;s.speedMs=0;
        std::vector<float>x(static_cast<int>(sr*2)),r(x.size());
        double hz=452;
        for(size_t i=0;i<x.size();++i)x[i]=r[i]=0.25f*static_cast<float>(std::sin(2*lumen::pi*hz*i/sr));
        for(int i=0;i<static_cast<int>(x.size());i+=127){int n=std::min(127,static_cast<int>(x.size())-i);e.process(x.data()+i,r.data()+i,n,s);}
        check(std::abs(e.frequency-hz)<2,"Pitch detector accuracy");
        for(size_t i=0;i<x.size();++i){check(std::isfinite(x[i]),"Finite output");check(x[i]==r[i],"Stereo coherence");}
        double output=spectralPeak(x,sr,430,465);
        check(std::abs(output-440)<3,"Correction output fundamental");
        std::cout<<"PASS "<<sr<<" Hz: detected "<<e.frequency<<" Hz, output peak "<<output<<" Hz\n";
        e.reset();std::fill(x.begin(),x.end(),0);e.process(x.data(),nullptr,static_cast<int>(x.size()),s);
        for(float sample:x)check(sample==0,"Silent input stays silent");
        check(e.confidence==0,"Silence has no pitch");
        e.prepare(sr);s.mix=0;
        // Let mix smoothing settle, then verify the dry impulse's declared delay.
        std::vector<float>dry(static_cast<int>(sr),0);e.process(dry.data(),nullptr,static_cast<int>(dry.size()),s);
        std::fill(dry.begin(),dry.end(),0);dry[0]=0.5f;e.process(dry.data(),nullptr,static_cast<int>(dry.size()),s);
        check(std::abs(dry[e.latency()]-0.5f)<0.0001f,"Dry delay compensation");
    }
    // Hosts may change block lengths at any time, including zero-length calls.
    for(int block:{1,32,64,127,512,2048}){
        lumen::Engine one,split;one.prepare(48000);split.prepare(48000);
        lumen::Settings settings;settings.speedMs=12;settings.drift=0;
        std::vector<float>a(12000),b;
        for(size_t i=0;i<a.size();++i)a[i]=0.2f*static_cast<float>(std::sin(2*lumen::pi*333*i/48000));
        b=a;one.process(a.data(),nullptr,static_cast<int>(a.size()),settings);
        split.process(b.data(),nullptr,0,settings);
        for(int i=0;i<static_cast<int>(b.size());i+=block)
            split.process(b.data()+i,nullptr,std::min(block,static_cast<int>(b.size())-i),settings);
        check(a==b,"Output invariant under host buffer size changes");
    }
    {
        lumen::Engine bypass;bypass.prepare(48000);lumen::Settings settings;settings.gainDb=6;settings.character=1;
        std::vector<float>impulse(4000,0);impulse[0]=0.5f;
        bypass.process(impulse.data(),nullptr,static_cast<int>(impulse.size()),settings,true);
        for(int i=0;i<static_cast<int>(impulse.size());++i)
            check(std::abs(impulse[i]-(i==bypass.latency()?0.5f:0))<1e-6f,"Bypass preserves dry signal and latency");
        bypass.prepare(96000);check(bypass.frequency==0,"Sample-rate change resets detector");
        check(bypass.latency()==1952,"Sample-rate change updates latency");
    }
    std::cout<<"PASS buffer sizes 1/32/64/127/512/2048, zero-length blocks, host bypass, sample-rate reset\n";
    lumen::Engine e;e.prepare(48000);lumen::Settings s;s.transpose=12;s.character=1;s.vibratoCents=100;
    std::mt19937 gen(4);std::uniform_real_distribution<float>d(-0.5f,0.5f);std::vector<float>noise(48000);
    for(auto& x:noise) x=d(gen);
    e.process(noise.data(),nullptr,static_cast<int>(noise.size()),s);
    for(float x:noise)check(std::isfinite(x)&&std::abs(x)<2,"Extreme controls stay finite");
    std::cout<<"PASS silence, scales, reset, mono/stereo, dry delay, extreme controls\n";
    return 0;
}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}}
