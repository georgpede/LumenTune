LUMEN TUNE 0.3 — EXPERIMENTAL WINDOWS RELEASE

Windows 10/11, 64-bit VST3 hosts. Primary intended host: FL Studio 26.
This is an original pitch-correction prototype, not an Antares product.

INSTALL
1. Extract the entire release ZIP.
2. Close FL Studio and other DAWs.
3. Run LumenTune-Setup.exe. Windows requests administrator permission because
   the installer writes to Program Files. This installer is not code-signed.
4. Open FL Studio > Options > File settings > Manage plugins.
5. Enable Verify plugins and run Find installed plugins.
6. Add Lumen Tune to a vocal mixer effect slot.

The installer writes only this plugin bundle:
C:\Program Files\Common Files\VST3\Lumen Tune.vst3

MANUAL INSTALL
Copy the included Lumen Tune.vst3 folder into the above VST3 directory.
Keep the entire bundle structure, including Contents and x86_64-win.

UNINSTALL
Close all DAWs, then delete only the Lumen Tune.vst3 bundle from the VST3
folder. This release adds no background services or registry entries.

FIRST USE
Use a dry, isolated single-voice vocal. Set the song key and scale first.
Clean Start: moderate correction. Neon Lock: fast, hard correction.
Soft Landing: gentler correction. Silver Motion: generated vibrato.
Low Orbit: octave-down effect. Presets retain your selected key and scale.

LIMITATIONS
This is an experimental, unsigned release, not a production-certified plugin.
The native Windows binary and installer have been cross-compiled; actual
Windows installation, GUI rendering and FL Studio scanning have NOT been
executed in this environment. See BUILD-REPORT.txt for exact checks.

DSP tests pass, but synthetic tests do not prove vocal transparency. The
simple granular shifter can produce coloration and grain artifacts. There is
no formant preservation, MIDI targeting, natural vibrato extraction, DVA,
custom note mask or Antares preset library. Nominal audio delay is about 21 ms
at 48 kHz; pitch detection adds response lag. Not intended for live monitoring.

This package does not contain a Mac binary. The corresponding source retains
Mac VST3/AU targets, which need a separate macOS build and host validation.
Pro Tools/AAX and 32-bit/VST2-only DAWs are not supported.

SOURCE AND LICENSE
The combined binary is distributed as open-source software under AGPLv3.
Original Lumen Tune files retain their MIT license; JUCE and its dependencies
retain their licenses. Source.zip contains corresponding project and JUCE
source, build configuration and installer code. See AGPL-3.0.txt and
THIRD-PARTY-NOTICES.txt. No warranty is provided.
