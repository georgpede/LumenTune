#define UNICODE
#define _UNICODE
#include <windows.h>
#include <shlobj.h>
#include <string>
#include <filesystem>
#include <stdexcept>
namespace fs=std::filesystem;
static const wchar_t* title=L"Lumen Tune 0.3 — experimental Windows VST3";
static std::wstring folder(REFKNOWNFOLDERID id){
    PWSTR p=nullptr;HRESULT hr=SHGetKnownFolderPath(id,0,nullptr,&p);
    if(FAILED(hr))throw std::runtime_error("Cannot locate Windows installation folders.");
    std::wstring result=p;CoTaskMemFree(p);return result;
}
static void extract(HINSTANCE instance,int resource,const fs::path& destination){
    auto r=FindResourceW(instance,MAKEINTRESOURCEW(resource),RT_RCDATA);
    if(!r)throw std::runtime_error("Installer resource is missing.");
    auto data=LockResource(LoadResource(instance,r));DWORD size=SizeofResource(instance,r);
    auto temp=destination;temp+=L".installing";
    HANDLE f=CreateFileW(temp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(f==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot write installation file. Close the DAW and retry.");
    DWORD written=0;BOOL ok=WriteFile(f,data,size,&written,nullptr);CloseHandle(f);
    if(!ok||written!=size){DeleteFileW(temp.c_str());throw std::runtime_error("File write failed.");}
    if(!MoveFileExW(temp.c_str(),destination.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){
        DeleteFileW(temp.c_str());throw std::runtime_error("Cannot replace plugin. Close all DAWs before installing.");
    }
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR,int){
    try{
        auto base=fs::path(folder(FOLDERID_ProgramFilesCommon))/L"VST3"/L"Lumen Tune.vst3";
        std::wstring prompt=L"Install Lumen Tune 0.3 for Windows 10/11 x64?\n\nThis is an unsigned, experimental pitch-correction plugin. It has not been tested inside FL Studio. Close all DAWs before continuing.\n\nDestination:\n"+base.wstring()+L"\n\nA previous Lumen Tune binary at this location will be replaced.\n\nNo compiler or internet connection is needed.";
        if(MessageBoxW(nullptr,prompt.c_str(),title,MB_YESNO|MB_ICONQUESTION)!=IDYES)return 0;
        auto binary=base/L"Contents"/L"x86_64-win";
        auto resources=base/L"Contents"/L"Resources";
        fs::create_directories(binary);fs::create_directories(resources);
        extract(instance,102,resources/L"README.txt");
        extract(instance,103,resources/L"AGPL-3.0.txt");
        extract(instance,104,resources/L"THIRD-PARTY-NOTICES.txt");
        extract(instance,101,binary/L"Lumen Tune.vst3");
        MessageBoxW(nullptr,L"Installed.\n\nFL Studio 26: open Options > File settings > Manage plugins. Enable Verify plugins, then Find installed plugins. Load Lumen Tune on a vocal mixer insert.\n\nTo uninstall: close all DAWs and delete the Lumen Tune.vst3 folder from the installation location.\n\nKeep the downloaded release package: it contains the corresponding source code.",title,MB_OK|MB_ICONINFORMATION);
        return 0;
    }catch(const std::exception& e){
        std::string text="Installation did not complete. Any files already copied may remain; rerun after correcting the issue.\n\n";text+=e.what();
        MessageBoxA(nullptr,text.c_str(),"Lumen Tune installation error",MB_OK|MB_ICONERROR);return 1;
    }
}
