#pragma once
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace lumen {
constexpr double pi = 3.14159265358979323846;
struct Settings {
    int root=0, scale=0; // chromatic, major, natural minor, pentatonic
    float speedMs=25, amount=1, tolerance=0, drift=0.2f;
    float transpose=0, vibratoCents=0, vibratoHz=5, character=0, mix=1, gainDb=0;
};
inline bool allowed(int note, int root, int scale) {
    constexpr int masks[]={4095, 2741, 1453, 661};
    return (masks[std::clamp(scale,0,3)] & (1 << ((note-root)%12+12)%12))!=0;
}
inline float targetNote(float note,int root,int scale) {
    int best=static_cast<int>(std::round(note)), bestTarget=best; float distance=100;
    for(int n=best-12;n<=best+12;++n) if(allowed(n,root,scale)) {
        float d=std::abs(note-n); if(d<distance){distance=d;bestTarget=n;}
    }
    return static_cast<float>(bestTarget);
}
class Engine {
    static constexpr int ringSize=32768, frameSize=512;
    std::array<std::array<float,ringSize>,2> audio{};
    std::array<float,frameSize> history{}, frame{}, difference{};
    double sr=48000, analysisRate=12000, grain=1440, phase=0, lfo=0;
    int write=0, decimate=4, counter=0, historyWrite=0, filled=0, hop=0;
    float lowpass=0, correction=0, desired=0, smoothMix=1, smoothGain=1, smoothCharacter=0;
    float read(int channel,double delay) const {
        double p=write-delay;
        while(p<0) p+=ringSize;
        int i=static_cast<int>(p); float t=static_cast<float>(p-i);
        return audio[channel][i%ringSize]*(1-t)+audio[channel][(i+1)%ringSize]*t;
    }
    void analyse(const Settings& s) {
        for(int i=0;i<frameSize;++i) frame[i]=history[(historyWrite+i)%frameSize];
        double energy=0; for(auto x:frame)energy+=x*x;
        if(energy/frameSize<0.00001){frequency=0; confidence=0; desired=0;return;}
        const int maxLag=std::min(230,static_cast<int>(analysisRate/60));
        const int minLag=std::max(2,static_cast<int>(analysisRate/1000));
        double cumulative=0; difference[0]=1;
        for(int lag=1;lag<=maxLag;++lag){
            double sum=0;
            for(int j=0;j<frameSize-maxLag;++j){double d=frame[j]-frame[j+lag];sum+=d*d;}
            cumulative+=sum;difference[lag]=cumulative>0?static_cast<float>(sum*lag/cumulative):1;
        }
        int lag=minLag;
        for(;lag<maxLag;++lag)if(difference[lag]<0.15f){
            while(lag+1<maxLag && difference[lag+1]<difference[lag])++lag;
            break;
        }
        if(lag>=maxLag){frequency=0;confidence=0;desired=0;return;}
        confidence=1-difference[lag];
        float denom=difference[lag-1]-2*difference[lag]+difference[lag+1];
        float sub=std::abs(denom)>1e-9f?0.5f*(difference[lag-1]-difference[lag+1])/denom:0;
        frequency=static_cast<float>(analysisRate/(lag+std::clamp(sub,-0.5f,0.5f)));
        inputMidi=69+12*std::log2(frequency/440.0f);
        targetMidi=targetNote(inputMidi,s.root,s.scale);
        float delta=targetMidi-inputMidi;
        desired=std::abs(delta)*100<=s.tolerance?0:delta*s.amount*(1-0.35f*s.drift);
    }
public:
    float frequency=0, confidence=0, inputMidi=0, targetMidi=0;
    void prepare(double sampleRate) {
        sr=sampleRate;decimate=std::max(1,static_cast<int>(sr/12000));analysisRate=sr/decimate;
        grain=std::min(8000.0,sr*0.040);reset();
    }
    int latency()const{return static_cast<int>(32+grain/2);}
    void reset(){
        for(auto& a:audio) a.fill(0);
        history.fill(0);frame.fill(0);difference.fill(0);
        write=counter=historyWrite=filled=hop=0;phase=lfo=0;
        lowpass=correction=desired=frequency=confidence=inputMidi=targetMidi=0;
        smoothMix=smoothGain=1;smoothCharacter=0;
    }
    void process(float* left,float* right,int samples,const Settings& s,bool bypass=false) {
        const float alpha=1-static_cast<float>(std::exp(-1/(sr*std::max(0.001f,s.speedMs*0.001f))));
        const float ramp=1-static_cast<float>(std::exp(-1/(sr*0.010)));
        const float lp=1-static_cast<float>(std::exp(-2*pi*2000/sr));
        const float gain=std::pow(10.0f,s.gainDb/20);
        for(int i=0;i<samples;++i){
            float l=std::isfinite(left[i])?left[i]:0, r=right?(std::isfinite(right[i])?right[i]:0):l;
            lowpass+=lp*((l+r)*0.5f-lowpass);
            if(++counter>=decimate){
                counter=0;history[historyWrite]=lowpass;historyWrite=(historyWrite+1)%frameSize;
                filled=std::min(frameSize,filled+1);
                if(++hop>=128){hop=0;if(filled==frameSize)analyse(s);}
            }
            correction+=alpha*(desired-correction);
            lfo+=s.vibratoHz/sr;lfo-=std::floor(lfo);
            double semitones=correction+s.transpose+(frequency>0?s.vibratoCents*0.01*std::sin(2*pi*lfo):0);
            double ratio=std::pow(2.0,std::clamp(semitones,-24.0,24.0)/12.0);
            phase+=(1-ratio)/grain;phase-=std::floor(phase);
            double other=phase+0.5;other-=std::floor(other);
            float w=static_cast<float>(0.5-0.5*std::cos(2*pi*phase));
            audio[0][write]=l;audio[1][write]=r;
            smoothMix+=ramp*(s.mix-smoothMix);smoothGain+=ramp*(gain-smoothGain);
            smoothCharacter+=ramp*(s.character-smoothCharacter);
            for(int ch=0;ch<(right?2:1);++ch){
                float wet=w*read(ch,32+phase*grain)+(1-w)*read(ch,32+other*grain);
                float drive=1+4*smoothCharacter;
                float colored=std::tanh(wet*drive)/std::tanh(drive);
                wet+=smoothCharacter*(colored-wet);
                float out=smoothGain*(smoothMix*wet+(1-smoothMix)*read(ch,latency()));
                (ch==0?left:right)[i]=bypass?read(ch,latency()):out;
            }
            write=(write+1)%ringSize;
        }
    }
};
}
