#include <JuceHeader.h>
#include "TuningEngine.h"
using APVTS=juce::AudioProcessorValueTreeState;
static constexpr const char* knobIds[]={"speed","amount","tolerance","drift","transpose","vdepth","vrate","character","mix","gain"};
static constexpr const char* knobNames[]={"SPEED / ms","CORRECTION","DEADBAND / cents","RELAX","TRANSPOSE / st","VIBRATO / cents","VIBRATO / Hz","CHARACTER","WET MIX","OUTPUT / dB"};
class Processor;
class Editor final:public juce::AudioProcessorEditor,private juce::Timer {
public:
    explicit Editor(Processor&);
    ~Editor()override{setLookAndFeel(nullptr);}
    void paint(juce::Graphics&)override;
    void resized()override;
private:
    void timerCallback()override{repaint(20,100,getWidth()-40,105);}
    Processor& p;
    juce::LookAndFeel_V4 theme;
    juce::ComboBox key,scale,preset;
    juce::Label keyLabel,scaleLabel,presetLabel;
    std::array<juce::Slider,10> knobs;
    std::array<juce::Label,10> labels;
    std::vector<std::unique_ptr<APVTS::SliderAttachment>> attachments;
    std::unique_ptr<APVTS::ComboBoxAttachment> keyAttachment,scaleAttachment;
};
class Processor final:public juce::AudioProcessor {
public:
    APVTS state;
    lumen::Engine engine;
    std::atomic<float> detected{0},target{0},confidence{0};
    static APVTS::ParameterLayout layout(){
        APVTS::ParameterLayout l;
        l.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID{"key",1},"Key",juce::StringArray{"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"},0));
        l.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID{"scale",1},"Scale",juce::StringArray{"Chromatic","Major","Natural minor","Major pentatonic"},0));
        auto add=[&](const char* id,const char* name,float lo,float hi,float value,float step){
            l.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{id,1},name,juce::NormalisableRange<float>(lo,hi,step),value));};
        add("speed","Tuning speed",0,200,25,0.1f);add("amount","Correction",0,1,1,0.001f);
        add("tolerance","Deadband cents",0,50,0,0.1f);add("drift","Relax",0,1,0.2f,0.001f);
        add("transpose","Transpose semitones",-12,12,0,1);add("vdepth","Vibrato cents",0,100,0,0.1f);
        add("vrate","Vibrato Hz",0.5f,10,5,0.01f);add("character","Character",0,1,0,0.001f);
        add("mix","Wet mix",0,1,1,0.001f);add("gain","Output dB",-24,6,0,0.1f);
        return l;
    }
    Processor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)),state(*this,nullptr,"LUMEN",layout()){
        const char* ids[]={"key","scale","speed","amount","tolerance","drift","transpose","vdepth","vrate","character","mix","gain"};
        for(size_t i=0;i<parameters.size();++i)parameters[i]=state.getRawParameterValue(ids[i]);
    }
    const juce::String getName()const override{return "Lumen Tune";}
    void prepareToPlay(double sr,int)override{engine.prepare(sr);setLatencySamples(engine.latency());}
    void releaseResources()override{}
    void reset()override{engine.reset();}
    bool isBusesLayoutSupported(const BusesLayout& l)const override{
        const auto in=l.getMainInputChannelSet(), out=l.getMainOutputChannelSet();
        return (in==juce::AudioChannelSet::mono() && (out==juce::AudioChannelSet::mono() || out==juce::AudioChannelSet::stereo()))
            || (in==juce::AudioChannelSet::stereo() && out==juce::AudioChannelSet::stereo());
    }
    void processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer&)override{processAudio(b,false);}
    void processBlockBypassed(juce::AudioBuffer<float>& b,juce::MidiBuffer&)override{processAudio(b,true);}
    void processAudio(juce::AudioBuffer<float>& b,bool bypass){
        juce::ScopedNoDenormals noDenormals;
        if(b.getNumChannels()==0)return;
        if(getTotalNumInputChannels()==1 && b.getNumChannels()>1)
            b.copyFrom(1,0,b,0,0,b.getNumSamples());
        auto v=[&](int n){return parameters[static_cast<size_t>(n)]->load();};
        lumen::Settings s;
        s.root=static_cast<int>(v(0));s.scale=static_cast<int>(v(1));s.speedMs=v(2);s.amount=v(3);
        s.tolerance=v(4);s.drift=v(5);s.transpose=v(6);s.vibratoCents=v(7);s.vibratoHz=v(8);
        s.character=v(9);s.mix=v(10);s.gainDb=v(11);
        engine.process(b.getWritePointer(0),b.getNumChannels()>1?b.getWritePointer(1):nullptr,b.getNumSamples(),s,bypass);
        detected.store(engine.inputMidi);target.store(engine.targetMidi);confidence.store(engine.confidence);
    }
    bool acceptsMidi()const override{return false;}
    bool producesMidi()const override{return false;}
    double getTailLengthSeconds()const override{return 0.1;}
    bool hasEditor()const override{return true;}
    juce::AudioProcessorEditor* createEditor()override{return new Editor(*this);}
    int getNumPrograms()override{return 1;}
    int getCurrentProgram()override{return 0;}
    void setCurrentProgram(int)override{}
    const juce::String getProgramName(int)override{return "Current";}
    void changeProgramName(int,const juce::String&)override{}
    void getStateInformation(juce::MemoryBlock& dest)override{
        auto xml=state.copyState().createXml();copyXmlToBinary(*xml,dest);
    }
    void setStateInformation(const void* data,int size)override{
        auto xml=getXmlFromBinary(data,size);
        if(xml && xml->hasTagName(state.state.getType().toString()))state.replaceState(juce::ValueTree::fromXml(*xml));
    }
    void applyPreset(int index){
        // Original starting points. Song key and scale deliberately remain user-controlled.
        static constexpr float values[5][10]={
            {25,1,0,0.2f,0,0,5,0,1,0},
            {0,1,0,0,0,0,5,0.1f,1,-1},
            {80,0.75f,8,0.7f,0,0,5,0,1,0},
            {12,1,0,0.1f,0,18,5.5f,0.3f,1,-2},
            {8,1,0,0,-12,8,4,0.5f,1,-3}};
        for(int i=0;i<10;++i)if(auto* parameter=state.getParameter(knobIds[i])){
            parameter->beginChangeGesture();parameter->setValueNotifyingHost(parameter->convertTo0to1(values[std::clamp(index,0,4)][i]));parameter->endChangeGesture();
        }
    }
private:
    std::array<std::atomic<float>*,12> parameters{};
};
Editor::Editor(Processor& processor):AudioProcessorEditor(processor),p(processor){
    theme.setColour(juce::Slider::rotarySliderFillColourId,juce::Colour(0xff9fffc7));
    theme.setColour(juce::Slider::rotarySliderOutlineColourId,juce::Colour(0xff33433d));
    theme.setColour(juce::Slider::thumbColourId,juce::Colours::white);
    theme.setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);
    theme.setColour(juce::ComboBox::backgroundColourId,juce::Colour(0xff1c2b25));
    theme.setColour(juce::ComboBox::outlineColourId,juce::Colour(0xff3c5147));
    setLookAndFeel(&theme);
    key.addItemList(juce::StringArray{"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"},1);
    scale.addItemList(juce::StringArray{"Chromatic","Major","Natural minor","Major pentatonic"},1);
    preset.addItemList(juce::StringArray{"Clean Start","Neon Lock","Soft Landing","Silver Motion","Low Orbit"},1);
    preset.setTextWhenNothingSelected("Choose starting point");
    preset.onChange=[this]{if(preset.getSelectedId()>0){p.applyPreset(preset.getSelectedId()-1);preset.setSelectedId(0,juce::dontSendNotification);}};
    addAndMakeVisible(key);addAndMakeVisible(scale);addAndMakeVisible(preset);
    auto label=[this](juce::Label& l,const char* text){l.setText(text,juce::dontSendNotification);l.setColour(juce::Label::textColourId,juce::Colour(0xff98b0a3));addAndMakeVisible(l);};
    label(keyLabel,"KEY");label(scaleLabel,"SCALE");label(presetLabel,"ORIGINAL PRESETS");
    keyAttachment=std::make_unique<APVTS::ComboBoxAttachment>(p.state,"key",key);
    scaleAttachment=std::make_unique<APVTS::ComboBoxAttachment>(p.state,"scale",scale);
    for(int i=0;i<10;++i){
        auto& k=knobs[i];k.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        k.setTextBoxStyle(juce::Slider::TextBoxBelow,false,86,22);addAndMakeVisible(k);
        label(labels[i],knobNames[i]);labels[i].setJustificationType(juce::Justification::centred);
        attachments.push_back(std::make_unique<APVTS::SliderAttachment>(p.state,knobIds[i],k));
    }
    setSize(850,600);startTimerHz(20);
}
void Editor::resized(){
    keyLabel.setBounds(28,213,100,20);key.setBounds(28,236,110,32);
    scaleLabel.setBounds(156,213,210,20);scale.setBounds(156,236,220,32);
    presetLabel.setBounds(510,213,310,20);preset.setBounds(510,236,312,32);
    for(int i=0;i<10;++i){int x=28+(i%5)*160,y=290+(i/5)*140;labels[i].setBounds(x,y,154,22);knobs[i].setBounds(x,y+24,154,112);}
}
void Editor::paint(juce::Graphics& g){
    g.fillAll(juce::Colour(0xff101b16));g.setColour(juce::Colour(0xffe6f5ed));g.setFont(32.0f);
    g.drawText("LUMEN / TUNE",28,22,500,42,juce::Justification::centredLeft);
    g.setFont(13.0f);g.setColour(juce::Colour(0xff98b0a3));
    g.drawText("MONOPHONIC PITCH LAB     /     0.3 EXPERIMENTAL",28,68,620,20,juce::Justification::centredLeft);
    g.setColour(juce::Colour(0xff1c2b25));g.fillRoundedRectangle(28,108,794,92,12);
    auto name=[](float n){const char* names[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};int note=juce::roundToInt(n);return juce::String(names[(note%12+12)%12])+juce::String(note/12-1);};
    bool voiced=p.confidence.load()>0.8f;
    g.setColour(juce::Colour(0xff9fffc7));g.setFont(28.0f);
    g.drawText(voiced?name(p.detected.load())+"  >  "+name(p.target.load()):"Listening...",48,120,330,40,juce::Justification::centredLeft);
    g.setFont(13.0f);g.setColour(juce::Colour(0xffb0c6b9));
    g.drawText("INPUT > SCALE TARGET",48,165,260,20,juce::Justification::centredLeft);
    juce::String detail=voiced?juce::String((p.target.load()-p.detected.load())*100,1)+" cents to nearest scale note":"Feed a dry, isolated vocal";
    g.drawText(detail,410,132,390,25,juce::Justification::centredRight);
    g.drawText("Granular engine / formants are not preserved",410,163,390,20,juce::Justification::centredRight);
    g.setFont(12.0f);g.drawText("RELAX leaves some pitch deviation. CHARACTER adds saturation. Mix 0 = delayed dry.",28,575,794,18,juce::Justification::centredLeft);
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new Processor();}
