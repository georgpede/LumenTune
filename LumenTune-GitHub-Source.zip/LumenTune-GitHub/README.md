# Lumen Tune

Original experimental monophonic pitch-correction plugin, recovered from the supplied 0.3 source archive.

## Project status
This repository contains the source, tests and manual Windows/macOS build workflows. It does not contain a newly validated release or Lumen Key. The supplied 0.3 Windows installer predates the Common Controls manifest hotfix discussed during development; it must not be labeled as the fixed build. Rebuild and validate before publishing a replacement installer.

The binaries are unsigned. Hosting here does not establish that an antivirus warning is a false positive. No antivirus scan or Windows/FL Studio runtime validation is claimed.

## Downloads and large files
Use GitHub Releases for installer archives, rather than committing ZIP files to the source tree. Include the corresponding source archive, licenses, build notes and SHA-256 checksums with each binary release. A checksum verifies file identity, not safety.

## Build
JUCE 8.0.6 is fetched at the pinned upstream commit by CMake. Windows: run `scripts/build-windows.ps1` with Visual Studio C++ build tools and CMake installed. macOS: run `bash scripts/build-macos.sh`. The manual workflow in `.github/workflows/native-builds.yml` builds packages for both systems; these packages still need host testing and are unsigned.

For engine tests only: `cmake -S . -B build-tests -DLUMEN_DSP_ONLY=ON`, then build and run CTest in that directory.

## Licensing
Original Lumen code: MIT (LICENSE). Combined JUCE-based plugin binaries: AGPL-3.0 (Installer/AGPL-3.0.txt). See Installer/THIRD-PARTY-NOTICES.txt. Distribute full corresponding source with binary releases. This original project is not affiliated with Antares or Image-Line.
