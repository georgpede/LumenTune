# Compatibility targets — v0.3

**No native DAW combination has been tested yet.** A Windows x64 binary and installer have been cross-compiled and inspected for the separate v0.3 experimental Windows release. This directory contains the corresponding source. “Target” means a format/architecture is configured, not that the host has passed validation. A source archive cannot be scanned or loaded as a plugin.

| Platform / host category | Configured target | Verification status |
|---|---|---|
| Windows 10/11 x64, FL Studio 26 | VST3 x64 | Windows x64 cross-build and PE inspection passed; DAW test pending |
| Other Windows x64 VST3-capable hosts/versions | VST3 x64 | Host-by-host testing required |
| macOS 11+ Intel or Apple Silicon, VST3-capable hosts | Universal VST3 | Native build and DAW tests pending; host may require a newer OS |
| macOS AUv2-capable hosts, including Logic Pro | Universal AU component | Native build, AU validation and DAW tests pending |
| Windows/macOS without a DAW | Standalone app | Device setup and microphone permissions need native testing |
| Pro Tools | No AAX binary or build target | Not supported in this release |
| Legacy 32-bit, VST2-only, DX, RTAS/TDM, AUv3-only, CLAP-only hosts | None | Not supported |
| Linux, iOS/iPadOS, Android, native Windows ARM64 | None validated/configured as a release target | Outside this release's scope |

Windows and macOS need separate compiled files. Even a universal Mac binary is not a Windows binary. No claim covers every historical or future DAW version. Format support is necessary, but a DAW's scanner, architecture, OS minimum, sandbox, edition and version restrictions also matter.

## Installation after successful compilation

- Windows VST3: copy the complete `Lumen Tune.vst3` bundle into `C:\Program Files\Common Files\VST3`.
- Mac VST3: copy the complete `.vst3` bundle into `~/Library/Audio/Plug-Ins/VST3`.
- Mac AU: copy `Lumen Tune.component` into `~/Library/Audio/Plug-Ins/Components`.
- FL Studio 26: Options > File settings > Manage plugins; enable Verify plugins and Find installed plugins. Load it as a vocal mixer effect.
- Other DAWs: rescan using that host's plugin manager. For hosts that support both AU and VST3, keep the same format in a project; these are distinct plugin instances.
- The standalone app is a separate input/output processor; it does not provide plugin compatibility to unsupported DAWs.

## Build automation

`scripts/build-windows.ps1` builds Windows x64 VST3 and standalone targets. `scripts/build-macos.sh` builds Intel/Apple Silicon VST3, AU and standalone targets.

The supplied `.github/workflows/native-builds.yml` can be run manually after you place the contents of this project at a GitHub repository root. It builds both platforms, runs DSP tests and packages the binaries as workflow artifacts. **This workflow has not been executed here.** A green build is not a DAW compatibility certification. It does not sign Windows distributions or notarize Mac distributions.

## Host validation checklist

Record exact OS, architecture, DAW version, plugin format, buffer size and sample rate with each result.

1. Scan and instantiate on mono, stereo and mono-to-stereo effect tracks. Surround is not supported.
2. Save/reopen a project with nondefault settings and parameter automation. Verify exact recall.
3. Compare playback and offline rendering, including silence, stop/start, reset and repeated instances.
4. Exercise buffers 32–2048 samples, sample-rate changes, and 44.1/48/88.2/96/192 kHz sessions. Higher-rate native and CPU tests are pending.
5. Toggle host bypass. The processor now supplies a delayed dry path when the host calls its bypass callback; hosts that suspend it may behave differently.
6. Verify latency compensation on an impulse against a dry reference. Wet granular timing varies around the declared center delay.
7. Check full-scale inputs, saturated presets and gain automation for overloads; no limiter is included.
8. Run pluginval/VST3 validation and macOS Audio Unit validation. After installing AU, the configured identifiers are `auval -v aufx Lmtu Lumn`.
9. Listen to exposed vocals over the detector range. Format compatibility does not establish audio quality.

## Format references

- JUCE CMake format documentation (8.0.6): https://github.com/juce-framework/JUCE/blob/8.0.6/docs/CMake%20API.md
- Image-Line installation and format guidance: https://www.image-line.com/fl-studio-learning/fl-studio-online-manual/html/basics_externalplugins.htm
- Avid AAX SDK and signing prerequisites: https://developer.avid.com/aax/

AAX is a separate future integration requiring the appropriate SDK, agreements and signing workflow; changing a filename or choosing VST3 does not make a Pro Tools plugin.
